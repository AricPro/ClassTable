package com.cqgroup;

/**
 * Created by handsomeliu on 2017/4/18.
 */

public class Teacher_Info {
    private int id;
    private String teacherName;
    private String teacherId;

    public Teacher_Info() {
    }
    public Teacher_Info(int id, String teacherName, String teacherId) {
        this.id = id;
        this.teacherName = teacherName;
        this.teacherId = teacherId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTeacher_name() {
        return teacherName;
    }

    public void setTeacher_name(String teacher_name) {
        this.teacherName = teacher_name;
    }

    public String getTeacher_id() {
        return teacherId;
    }

    public void setTeacher_id(String teacher_id) {
        this.teacherId = teacher_id;
    }

    @Override
    public String toString() {
        return teacherId + "...." + teacherName;
    }
}
