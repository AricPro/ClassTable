package com.cqgroup;

import android.content.Context;
import android.content.SharedPreferences;

public class CacheUtils {
	
	/**
	 * @param context
	 * @param key
	 * @param value
	 */
	private static final String CACHE_FILE_NAME = "classes";
	private static SharedPreferences mSharedPreferences;
	
	
	public static void putString(Context context, String key, String value) {
		
		if(mSharedPreferences == null) {
			mSharedPreferences = context.getSharedPreferences(CACHE_FILE_NAME, Context.MODE_PRIVATE);
		}
		mSharedPreferences.edit().putString(key, value).commit();
	}
	
	/**
	 * @param context
	 * @param key
	 * @param defValue
	 * @return
	 */
	public static String getString(Context context, String key, String defValue) {
		if(mSharedPreferences == null) {
			mSharedPreferences = context.getSharedPreferences(CACHE_FILE_NAME, Context.MODE_PRIVATE);
		}
		return mSharedPreferences.getString(key, defValue);
	}
}
