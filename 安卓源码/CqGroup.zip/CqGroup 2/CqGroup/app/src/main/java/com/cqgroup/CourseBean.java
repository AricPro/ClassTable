package com.cqgroup;

/**
 * Created by handsomeliu on 2017/4/15.
 */

public class CourseBean {
    private int id;
    private String courseId;
    private String courseName;

    public CourseBean() {
    }

    public CourseBean(String courseId, String courseName) {
        this.courseId = courseId;
        this.courseName = courseName;
    }

    public String getCourseId() {
        return courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
}
