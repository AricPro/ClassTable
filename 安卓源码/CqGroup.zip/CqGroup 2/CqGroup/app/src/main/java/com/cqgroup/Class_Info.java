package com.cqgroup;

/**
 * Created by handsomeliu on 2017/4/14.
 */

public class Class_Info {
    private String class_name;
    private String class_hour;
    private String teach_hour;
    private String test_hour;
    private String operate_hour;
    private String other_hour;
    private String class_num;
    private String people_num;
    private String class_composition;
    private String week;
    private String lesson;


    public Class_Info(String class_name, String class_hour, String teach_hour,
                    String test_hour, String operate_hour, String other_hour,
                    String class_num, String people_num, String class_composition,
                    String week, String lesson) {
        this.class_name = class_name;
        this.class_hour = class_hour;
        this.teach_hour = teach_hour;
        this.test_hour = test_hour;
        this.operate_hour = operate_hour;
        this.other_hour = other_hour;
        this.class_num = class_num;
        this.people_num = people_num;
        this.class_composition = class_composition;
        this.week = week;
        this.lesson = lesson;
    }

    public Class_Info() {

    }

    public String getClass_name() {
        return class_name;
    }
    public void setClass_name(String class_name) {
        this.class_name = class_name;
    }
    public String getClass_hour() {
        return class_hour;
    }
    public void setClass_hour(String class_hour) {
        this.class_hour = class_hour;
    }
    public String getTeach_hour() {
        return teach_hour;
    }
    public void setTeach_hour(String teach_hour) {
        this.teach_hour = teach_hour;
    }
    public String getTest_hour() {
        return test_hour;
    }
    public void setTest_hour(String test_hour) {
        this.test_hour = test_hour;
    }
    public String getOperate_hour() {
        return operate_hour;
    }
    public void setOperate_hour(String operate_hour) {
        this.operate_hour = operate_hour;
    }
    public String getOther_hour() {
        return other_hour;
    }
    public void setOther_hour(String other_hour) {
        this.other_hour = other_hour;
    }
    public String getClass_num() {
        return class_num;
    }
    public void setClass_num(String class_num) {
        this.class_num = class_num;
    }
    public String getPeople_num() {
        return people_num;
    }
    public void setPeople_num(String people_num) {
        this.people_num = people_num;
    }
    public String getClass_composition() {
        return class_composition;
    }
    public void setClass_composition(String class_composition) {
        this.class_composition = class_composition;
    }
    public String getWeek() {
        return week;
    }
    public void setWeek(String week) {
        this.week = week;
    }
    public String getLesson() {
        return lesson;
    }
    public void setLesson(String lesson) {
        this.lesson = lesson;
    }


}
