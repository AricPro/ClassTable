package com.cqgroup;

/**
 * Created by handsomeliu on 2017/4/15.
 */

public class Constance {
    private static final String SERVER_IP = "http://115.159.98.175:8081";
    public static final String CLASSLIST_URL = SERVER_IP + "/ClassTable/getInfo/findCourseList";
//    public static final String CLASSLIST_URL = "http://xg.zdsoft.com.cn/ZNPK/Private/List_XNXQKC.aspx?xnxq=20160";
//    public static final String VALIDATE_URL = "http://xg.zdsoft.com.cn/sys/ValidateCode.aspx";
    public static final String VALIDATE_URL = SERVER_IP + "/ClassTable/validate";
//    public static final String CLASSTABLE_URL = "http://xg.zdsoft.com.cn/ZNPK/KBFB_LessonSel_rpt.aspx";
    public static final String CLASSTABLE_URL = SERVER_IP + "/ClassTable/getInfo/getTable";
    public static final String TEACHER_LIST_URL = SERVER_IP + "/ClassTable/teacherForm/findTeacherList";
//    public static final String TEACHER_LIST_URL = "115.159.143.115:8080/ClassTable/getInfo";
//    public static final String TeacherTABLE_URL = "http://xg.zdsoft.com.cn/ZNPK/TeacherKBFB_rpt.aspx";
    public static final String TeacherTABLE_URL = SERVER_IP + "/ClassTable/teacherForm/getTeacherTable";
}
