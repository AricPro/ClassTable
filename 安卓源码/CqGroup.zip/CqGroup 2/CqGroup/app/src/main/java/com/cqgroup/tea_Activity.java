package com.cqgroup;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by handsomeliu on 2017/4/13.
 */

public class tea_Activity extends Activity {
    private ImageView validateIv;
    private TextView getValidate;
    private Spinner teacherSpinner;
    private Spinner termSpinner;
    private EditText validateEt;
    private ListView teacherlv;

    TextView t_number;
    TextView classnameTv;
    TextView scoreTv;
    TextView typeTv;
    TextView classtypeTv;
    TextView classNumTv;
    TextView whoTv;
    TextView peoplenumTv;
    TextView timeTv;
    TextView siteTv;

    private Bitmap validate_png;
    private ArrayAdapter teacherListAdapter;
    private ArrayAdapter timeAdapter;
    private Teacher_ClassAdapter adapter;

    private String term = "";
    private String teacherId = "";

    List<Teacher_Info> list = new ArrayList<>();
    List<String> teacher = new ArrayList<>();
    List<String> teacherId_list = new ArrayList<>();
    List<Tea_Info> tea_infos = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.teacher_layout);
        teacherlv =(ListView)findViewById(R.id.teacher_classLv);
        validateEt = (EditText) findViewById(R.id.edit_checknum_tc);
        termSpinner = (Spinner) findViewById(R.id.spinner_year_teacher);
        teacherSpinner = (Spinner) findViewById(R.id.spinner_teacher_teacher);
        getValidate = (TextView) findViewById(R.id.validate_course_tv);
        validateIv = (ImageView) findViewById(R.id.validate_teacher);

        String[] timeSouce = {"2016-2017学年第一学期"};
        term = "20160";
        getInitData();
        teacherListAdapter = new ArrayAdapter(this,R.layout.spanner_class_item,R.id.spinner_item,teacher);
        teacherListAdapter.setDropDownViewResource(R.layout.dropdown_style);
        timeAdapter = new ArrayAdapter(this,R.layout.spanner_class_item,R.id.spinner_item,timeSouce);
        adapter = new Teacher_ClassAdapter(this,R.layout.teacher_class_layout,tea_infos);

        teacherlv.setOnItemClickListener(new MyClickListener());

        termSpinner.setAdapter(timeAdapter);
        teacherSpinner.setAdapter(teacherListAdapter);
        teacherlv.setAdapter(adapter);

        teacherSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                System.out.println("点了一下");
                teacherSpinner.setSelection(position);
                System.out.println(teacherId);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }
    private void getInitData(){
        System.out.println("开始获取课程列表");
        new Thread(new Runnable(){
            @Override
            public void run() {
                list = NetWorkUtil.getTeacherList(Constance.TEACHER_LIST_URL);

                teacher.add("请选择");
                teacherId_list.add(null);
                for (Teacher_Info tea : list) {
                    teacher.add(tea.getTeacher_name());
                    teacherId_list.add(tea.getTeacher_id());
                }
                tea_Activity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        teacherListAdapter.notifyDataSetChanged();
                    }
                });
            }
        }).start();
    }
    public void getValidate(View view){
        getValidate();
    }
    private void getValidate(){
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                validate_png = NetWorkUtil.getVolidate(Constance.VALIDATE_URL);
            }
        });
        t.start();
        try {
            t.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        validateIv.setImageBitmap(validate_png);
    }
    public void getCourse(View view){
        final String validate = validateEt.getText().toString();
        teacherId = teacher.get(teacherSpinner.getSelectedItemPosition());
        int index = teacher.indexOf(teacherId);
        final JsonUtil<Tea_Info> ju = new JsonUtil<>();
        teacherId = teacherId_list.get(index);
        final String timeId = "20160";
        if(TextUtils.isEmpty(validate)){
            Toast.makeText(this, "请输入验证码",Toast.LENGTH_LONG).show();
        }else if(TextUtils.isEmpty(teacherId)){
            Toast.makeText(this, "请选择课程", Toast.LENGTH_SHORT).show();
        }else {
            new Thread() {
                public void run() {
                    String key = timeId + "#" + teacherId;
                    List<Tea_Info> tea_io = null;
                    String json = CacheUtils.getString(tea_Activity.this, key, null);
                    if(json == null) {
                        tea_io = NetWorkUtil.getTeacherTable(Constance.TeacherTABLE_URL, timeId, teacherId, validate);
                        if(tea_io == null){
                            tea_Activity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(tea_Activity.this, "验证码错误！", Toast.LENGTH_LONG).show();
                                    getValidate();
                                }
                            });
                            return;
                        }else{
                            CacheUtils.putString(tea_Activity.this, key, ju.toJson(tea_io));
                        }
                    }else {
                        tea_io = ju.toTList(json);
                        System.out.println("有缓存。。。");
                    }
                    tea_infos.addAll(tea_io);
                    tea_infos.clear();
                    tea_infos.addAll(tea_io);
                    tea_Activity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            adapter.notifyDataSetChanged();
                        }
                    });
                }
            }.start();
        }
    }
    class MyClickListener implements AdapterView.OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            System.out.println("点了一下课表......");
            LayoutInflater inflater = (LayoutInflater) tea_Activity.this.getSystemService(LAYOUT_INFLATER_SERVICE);
            final View v = inflater.inflate(R.layout.class_detail, null);

            t_number = (TextView) v.findViewById(R.id.tv_tnumber_text);
            classnameTv = (TextView) v.findViewById(R.id.tv_class_text);
            scoreTv = (TextView) v.findViewById(R.id.tv_score_text);
            typeTv = (TextView) v.findViewById(R.id.tv_howtoclass_text);
            classtypeTv = (TextView) v.findViewById(R.id.tv_class_type_text);
            classNumTv = (TextView) v.findViewById(R.id.tv_class_id_text);
            whoTv = (TextView) v.findViewById(R.id.tv_class_who_text);
            peoplenumTv = (TextView) v.findViewById(R.id.tv_stu_num_text);
            timeTv = (TextView) v.findViewById(R.id.tv_time_text);
            siteTv = (TextView) v.findViewById(R.id.tv_site_text);

            Tea_Info info = tea_infos.get(position);
            t_number.setText(info.getId());
            classnameTv.setText(info.getCourse());
            scoreTv.setText(info.getScore());
            typeTv.setText(info.getStduyway());
            classtypeTv.setText(info.getLesson());
            classNumTv.setText(info.getClass_id());
            whoTv.setText(info.getClass_num());
            peoplenumTv.setText(info.getStu_count());
            timeTv.setText(info.getTime());
            siteTv.setText(info.getSite());

            System.out.println(info.toString());
            new AlertDialog.Builder(tea_Activity.this).setTitle("详细课程信息").setView(v).setCancelable(true).
                    setPositiveButton(null, null).setNegativeButton(null, null).show();
        }
    }
}
