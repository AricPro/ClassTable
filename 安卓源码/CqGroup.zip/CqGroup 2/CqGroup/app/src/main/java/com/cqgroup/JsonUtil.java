package com.cqgroup;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JsonUtil<E> {
    public String toJson(List<E> list){
        Gson gson = new Gson();
        String json = gson.toJson(list);
        return json;
    }
    public static List<Cou_Info> toCList(String json){
        List<Cou_Info> info = new ArrayList<>();
        Gson gson = new Gson();
        info = gson.fromJson(json, new TypeToken<List<Cou_Info>>(){}.getType());
        return info;
    }
    public static List<Tea_Info> toTList(String json){
        List<Tea_Info> info = new ArrayList<>();
        Gson gson = new Gson();
        info = gson.fromJson(json, new TypeToken<List<Tea_Info>>(){}.getType());
        return info;
    }
}

