package com.cqgroup;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class NetWorkUtil {
    private static String cookie = "";
    /**
     * 获取课程列表
     * @param urlstr
     * @return
     */
    public static List<Teacher_Info> getTeacherList(String urlstr){
        List<Teacher_Info> teacherInfo= new ArrayList<Teacher_Info>();
        HttpURLConnection con = null;
        InputStream is = null;
        BufferedReader reader = null;
        System.out.println("获取教师列表。。。");
        try {
            URL url = new URL(urlstr);
            con = (HttpURLConnection) url.openConnection();
            is = con.getInputStream();
            reader = new BufferedReader(new InputStreamReader(is,"UTF-8"));
            String lines = null;
            StringBuilder sbr = new StringBuilder("");
            System.out.println("能行不....");
            while((lines=reader.readLine()) != null){
                sbr.append(lines);
            }
            Gson gson = new Gson();
            System.out.println(sbr.toString());

            teacherInfo = gson.fromJson(sbr.toString(), new TypeToken<List<Teacher_Info>>(){}.getType());
            for (Teacher_Info t: teacherInfo) {
                System.out.println(t.toString());
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            try {
                if(reader != null)
                    reader.close();
                if(is != null)
                    is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            con.disconnect();
        }
        return teacherInfo;
    }
    public static List<CourseBean> getClassList(String urlstr) {
        System.out.println("从网上获取课程信息呀...");
        List<CourseBean> classesInfo = new ArrayList<CourseBean>();
        HttpURLConnection con = null;
        InputStream is = null;
        BufferedReader reader = null;
        try {
            URL url = new URL(urlstr);
            con = (HttpURLConnection) url.openConnection();
            is = con.getInputStream();
            reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            String lines = null;
            StringBuilder sbr = new StringBuilder("");
            while ((lines = reader.readLine()) != null) {
                sbr.append(lines);
            }
            Gson gson = new Gson();
            classesInfo = gson.fromJson(sbr.toString(), new TypeToken<List<CourseBean>>(){}.getType());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (reader != null)
                    reader.close();
                if (is != null)
                    is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (con != null)
            con.disconnect();
        }
        return classesInfo;
    }
    public static Bitmap getVolidate(String urlStr){
        HttpURLConnection con = null;
        InputStream is = null;
        Bitmap bitmap = null;
        try {
            URL url = new URL(urlStr);
            con = (HttpURLConnection) url.openConnection();
            con.setRequestProperty("Cookie", cookie);
            is = con.getInputStream();
            bitmap = BitmapFactory.decodeStream(is);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            try {
                if (is != null)
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            con.disconnect();
        }
        return bitmap;
    }
    public static List<Cou_Info> getClassTable(String urlStr, String time, String clas, String validate){
        List<Cou_Info> tablelist = new ArrayList<Cou_Info>();
        try {
            urlStr = urlStr + "/" + clas + "/validate/" + validate;
            URL url = new URL(urlStr);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("Content-Type","application/json");

            if(con.getResponseCode() == 200){
                System.out.println("连接成功");
             }else{
                System.out.println("连接失败");
             }
            InputStream is = con.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder result = new StringBuilder("");
            String lines;
            while((lines=reader.readLine()) != null){
                result.append(lines);
            }
            System.out.println(result.toString());
            if(TextUtils.isEmpty(result)){
                return null;
            }
            tablelist = JsonUtil.toCList(result.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tablelist;
    }
    public static List<Tea_Info> getTeacherTable(String urlStr, String time, String t, String validate){
        List<Tea_Info> tablelist = new ArrayList<Tea_Info>();
        urlStr = urlStr + "/" + t + "/validate/" + validate;
        try {
            URL url = new URL(urlStr);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("Content-Type","application/json");

            if(con.getResponseCode() == 200){
                System.out.println("连接成功");
            }else{
                System.out.println("连接失败");
            }
            InputStream is = con.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder result = new StringBuilder("");
            String lines;
            while((lines=reader.readLine()) != null){
                result.append(lines);
            }
            tablelist = JsonUtil.toTList(result.toString());

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tablelist;
    }
}
