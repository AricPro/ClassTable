package com.cqgroup;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by handsomeliu on 2017/4/18.
 */

public class Teacher_ClassAdapter extends ArrayAdapter<Tea_Info> {
    private Context context;
    private int resource;
    private List<Tea_Info> tea_infos;

    public Teacher_ClassAdapter(Context context,int resource,List<Tea_Info> objects){
        super(context,resource,objects);
        this.context = context;
        this.resource = resource;
        this.tea_infos = objects;
    }

    public View getView(int position, View convertView, ViewGroup parent){
        final Tea_Info c = tea_infos.get(position);

        convertView = LayoutInflater.from(context).inflate(resource,parent,false);
        TextView t_number = (TextView)convertView.findViewById(R.id.tnumber_textView);
        TextView classnameTv = (TextView)convertView.findViewById(R.id.classname_textView);
        TextView scoreTv = (TextView)convertView.findViewById(R.id.score_textView);
        TextView typeTv = (TextView)convertView.findViewById(R.id.type_textView);
        TextView classtypeTv = (TextView)convertView.findViewById(R.id.classType_textView);
        TextView classNumTv = (TextView)convertView.findViewById(R.id.classnumber_textView);
        TextView whoTv = (TextView)convertView.findViewById(R.id.whotoclass_textView);
        TextView peoplenumTv = (TextView)convertView.findViewById(R.id.peopleNum_textView);
        TextView timeTv = (TextView)convertView.findViewById(R.id.time_textView);
        TextView siteTv = (TextView)convertView.findViewById(R.id.t_site_textView);

        t_number.setText(c.getId());
        classnameTv.setText(c.getCourse());
        scoreTv.setText(c.getScore());
        typeTv.setText(c.getStduyway());
        classtypeTv.setText(c.getLesson());
        classNumTv.setText(c.getClass_id());
        whoTv.setText(c.getClass_num());
        peoplenumTv.setText(c.getStu_count());
        timeTv.setText(c.getTime());
        siteTv.setText(c.getSite());

        return convertView;
    }



}
