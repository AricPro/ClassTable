package com.cqgroup;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;

/**
 * Created by handsomeliu on 2017/4/14.
 */

public class CourseApapter extends ArrayAdapter<Cou_Info>{
    private Context context;
    private int resource;
    private List<Cou_Info> cou_infos;

    public CourseApapter(Context context,int resource,List<Cou_Info> objects){
        super(context,resource,objects);
        this.context = context;
        this.resource = resource;
        this.cou_infos = objects;
    }

    public View getView(int position, View convertView, ViewGroup parent){
        final Cou_Info c = cou_infos.get(position);

        convertView = LayoutInflater.from(context).inflate(resource,parent,false);
        TextView tnameTv = (TextView)convertView.findViewById(R.id.tname_textView);
        TextView class_numTv = (TextView)convertView.findViewById(R.id.classnum_textView);
        TextView numTv = (TextView)convertView.findViewById(R.id.num_textView);
        TextView course_nameTv = (TextView)convertView.findViewById(R.id.cname_textView);
        TextView checkwayTv = (TextView)convertView.findViewById(R.id.checkway_textView);
        TextView constituteTv = (TextView)convertView.findViewById(R.id.constitute_textView);
        TextView weektimeTv = (TextView)convertView.findViewById(R.id.weektime_textView);
        TextView classtimeTv = (TextView)convertView.findViewById(R.id.classnum_textView);
        TextView siteTv = (TextView)convertView.findViewById(R.id.site_textView);

        tnameTv.setText(c.getTeacher_name());
        class_numTv.setText(c.getClass_num());
        numTv.setText(c.getNum());
        course_nameTv.setText(c.getCourse_name());
        checkwayTv.setText(c.getCheckway());
        constituteTv.setText(c.getConstitute());
        weektimeTv.setText(c.getWeek_time());
        classtimeTv.setText(c.getClass_time());
        siteTv.setText(c.getSite());

        return convertView;
    }



}
