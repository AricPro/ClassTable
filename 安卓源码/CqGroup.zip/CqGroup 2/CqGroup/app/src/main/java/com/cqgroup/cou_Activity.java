package com.cqgroup;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by handsomeliu on 2017/4/13.
 */

public class cou_Activity extends Activity{
    private ListView courselv;
    private CourseApapter adapter;
    private List<Cou_Info> cou_infos = new ArrayList<Cou_Info>();
    private EditText validateEt;
    private Spinner termSpinner;
    private Spinner classSpinner;
    private ArrayAdapter classlistAdapter = null;
    private ArrayAdapter timeAdapter = null;
    private ImageView validateIv = null;
    private TextView getValidate = null;
    private Bitmap validate_png = null;
    private TextView tv_teacher_name;
    private TextView tv_class_no;
    private TextView tv_people_num;
    private TextView tv_class_catogry;
    private TextView tv_exam_tpye;
    private TextView tv_goucheng;
    private TextView tv_week_time;
    private TextView tv_jieci;
    private TextView tv_site;
    private String courseId = "";
    private String term = "";
    List<CourseBean> list = new ArrayList<>();
    List<String> course = new ArrayList<>();
    List<String> courseId_list = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.course_layout);
        courselv =(ListView)findViewById(R.id.courseLv);
        validateEt = (EditText) findViewById(R.id.edit_checknum);
        termSpinner = (Spinner) findViewById(R.id.spinner_year);
        classSpinner = (Spinner) findViewById(R.id.spinner_course);
        getValidate = (TextView) findViewById(R.id.validate_course_tv);
        validateIv = (ImageView) findViewById(R.id.validate_iv);

        String[] timeSouce = {"2016-2017学年第一学期"};
        term = "20160";
        getInitData();
        classlistAdapter = new ArrayAdapter(this,R.layout.spanner_class_item,R.id.spinner_item,course);
        classlistAdapter.setDropDownViewResource(R.layout.dropdown_style);
        timeAdapter = new ArrayAdapter(this,R.layout.spanner_class_item,R.id.spinner_item,timeSouce);
        adapter = new CourseApapter(this,R.layout.cou_layout,cou_infos);

        courselv.setOnItemClickListener(new MyClickListener());

        termSpinner.setAdapter(timeAdapter);
        classSpinner.setAdapter(classlistAdapter);
        courselv.setAdapter(adapter);

        classSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                System.out.println("点了一下");
                classSpinner.setSelection(position);
                System.out.println(courseId);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        classSpinner.setVisibility(View.VISIBLE);

    }
    private void getInitData(){
        System.out.println("开始获取课程列表");
        new Thread(new Runnable(){
            @Override
            public void run() {
                list = NetWorkUtil.getClassList(Constance.CLASSLIST_URL);
                course.add("请选择");
                courseId_list.add(null);
                for (CourseBean clas : list) {
                    course.add(clas.getCourseName());
                    courseId_list.add(clas.getCourseId());
                }
                System.out.println(course.size() + "....."+courseId_list.size());
                cou_Activity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        classlistAdapter.notifyDataSetChanged();
                    }
                });
            }
        }).start();

    }

    /**
     * 获取验证码
     * @param view
     */
   public void getValidate(View view){
       getValidate();
    }
    private void getValidate(){
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                validate_png = NetWorkUtil.getVolidate(Constance.VALIDATE_URL);
            }
        });
        t.start();
        try {
            t.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        validateIv.setImageBitmap(validate_png);
    }
    public void getCourse(View view){
        final String validate = validateEt.getText().toString();
        courseId = course.get(classSpinner.getSelectedItemPosition());
        int index = course.indexOf(courseId);
        courseId = courseId_list.get(index);
        final JsonUtil<Cou_Info> ju = new JsonUtil<>();
        final String timeId = "20160";
        if(TextUtils.isEmpty(validate)){
            Toast.makeText(this, "请输入验证码",Toast.LENGTH_LONG).show();
        }else if(TextUtils.isEmpty(courseId)){
            Toast.makeText(this, "请选择课程", Toast.LENGTH_SHORT).show();
        }else {
            new Thread() {
                public void run() {
                    String key = timeId + "#" + courseId;
                    List<Cou_Info> cou_io = null;
                    String json = CacheUtils.getString(cou_Activity.this, key, null);
                    if(json == null) {
                        cou_io = NetWorkUtil.getClassTable(Constance.CLASSTABLE_URL, timeId, courseId, validate);
                        if(cou_io == null){
                            cou_Activity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(cou_Activity.this, "验证码错误！", Toast.LENGTH_LONG).show();
                                    getValidate();
                                }
                            });
                            return;
                        }else{
                            CacheUtils.putString(cou_Activity.this, key, ju.toJson(cou_io));
                        }
                    }else {
                        cou_io = ju.toCList(json);
                        System.out.println("有缓存。。。");
                    }
                    cou_infos.addAll(cou_io);
                    cou_infos.clear();
                    cou_infos.addAll(cou_io);
                    cou_Activity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            adapter.notifyDataSetChanged();
                        }
                    });
                }
            }.start();
        }
    }
    class MyClickListener implements AdapterView.OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            System.out.println("点了一下课表......");
            LayoutInflater inflater = (LayoutInflater) cou_Activity.this.getSystemService(LAYOUT_INFLATER_SERVICE);
            final View v = inflater.inflate(R.layout.course_detail, null);

            tv_teacher_name = (TextView) v.findViewById(R.id.tv_teacher_name);
            tv_class_no = (TextView)  v.findViewById(R.id.tv_class_num_text);
            tv_people_num = (TextView)  v.findViewById(R.id.tv_people_num_text);
            tv_class_catogry = (TextView)  v.findViewById(R.id.tv_class_catogry_text);
            tv_exam_tpye = (TextView)  v.findViewById(R.id.tv_exam_type_text);
            tv_goucheng = (TextView)  v.findViewById(R.id.tv_class_goucheng_text);
            tv_week_time = (TextView)  v.findViewById(R.id.tv_week_time_text);
            tv_jieci = (TextView)  v.findViewById(R.id.tv_jieci_text);
            tv_site = (TextView)  v.findViewById(R.id.tv_site_text);

            Cou_Info info = cou_infos.get(position);
            tv_teacher_name.setText(info.getTeacher_name());
            tv_class_no.setText(info.getClass_num());
            tv_people_num.setText(info.getNum());
            tv_class_catogry.setText("公共课／必修课");
            tv_exam_tpye.setText(info.getCheckway());
            tv_goucheng.setText(info.getConstitute());
            tv_week_time.setText(info.getWeek_time());
            tv_jieci.setText(info.getClass_time());
            tv_site.setText(info.getSite());
            new AlertDialog.Builder(cou_Activity.this).setTitle("详细课程信息").setView(v).setCancelable(true).
                    setPositiveButton(null,null).setNegativeButton(null,null).show();
        }
    }
}
