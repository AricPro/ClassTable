package com.cqgroup;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ParseCourse {
    public static List<Cou_Info> courseParse(String json){
        List<Cou_Info> cou_infos = new ArrayList<Cou_Info>();
        try {
            JSONArray jsa = new JSONArray(json);
            for (int i=0;i<jsa.length();i++){
                JSONObject jso = (JSONObject)jsa.get(i);
                Cou_Info c = new Cou_Info("0",jso.getString("teacher_name"),jso.getString("class_num"),jso.getString("num"),jso.getString("course_name"),jso.getString("checkway"),jso.getString("constitute"),jso.getString("week_time"),jso.getString("class_time"),jso.getString("site"));
                cou_infos.add(c);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return cou_infos;
    }
}
