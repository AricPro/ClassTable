package com.cqgroup;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {

    private RelativeLayout cou_RelaytiveLayout;
    private RelativeLayout tea_RelaytiveLayout;
    private RelativeLayout cla_RelaytiveLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cou_RelaytiveLayout = (RelativeLayout)findViewById(R.id.rl_h1);
        tea_RelaytiveLayout = (RelativeLayout)findViewById(R.id.rl_h2);
        cla_RelaytiveLayout = (RelativeLayout)findViewById(R.id.rl_h3);

        cou_RelaytiveLayout.setOnClickListener(new cou_buttonListener());
        tea_RelaytiveLayout.setOnClickListener(new tea_buttonListener());
        cla_RelaytiveLayout.setOnClickListener(new cla_buttonListener());
    }

    class cou_buttonListener implements OnClickListener{
        public void onClick(View view){
            Intent intent = new Intent();
            intent.setClass(MainActivity.this,cou_Activity.class);
            MainActivity.this.startActivity(intent);
        }
    }
    class tea_buttonListener implements OnClickListener{
        public void onClick(View view){
            Intent intent = new Intent();
            intent.setClass(MainActivity.this,tea_Activity.class);
            MainActivity.this.startActivity(intent);
        }
    }
    class cla_buttonListener implements OnClickListener{
        public void onClick(View view){
            Intent intent = new Intent();
            intent.setClass(MainActivity.this,cla_Activity.class);
            MainActivity.this.startActivity(intent);
        }
    }
}
